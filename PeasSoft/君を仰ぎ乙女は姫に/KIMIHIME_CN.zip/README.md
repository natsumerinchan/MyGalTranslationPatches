# 君を仰ぎ乙女は姫に gpt-4o-2024-05-13 翻译补丁

作者： natsumerinchan(Github) == 雨宮ゆうこ(2dfan)

未作测试，可能会出现漏翻，还请多多反馈bug！！！3q
 
## 使用方法
解压压缩包并把所有文件复制到游戏根目录，双击tukusi3.exe运行(无需手动转区因为UniversalInjectorFramework会自动处理)

# Credits

- [SakuraLLM/SakuraLLM](https://github.com/SakuraLLM/SakuraLLM.git) :适配轻小说/Galgame的日中翻译大模型
- [xd2333/GalTransl](https://github.com/xd2333/GalTransl.git) :支持GPT-3.5/GPT-4/Newbing/Sakura等大语言模型的Galgame自动化翻译解决方案
- [crskycode/GARbro](https://github.com/crskycode/GARbro) :Yuka System视觉小说引擎的解包和打包工具
- [AtomCrafty/UniversalInjectorFramework](https://github.com/AtomCrafty/UniversalInjectorFramework.git) :实现自动转区和更改字体
- [satan53x/SExtractor](https://github.com/satan53x/SExtractor.git) :从GalGame脚本提取和导入文本（还借用了其中的JIS替换字体）
- [xupefei/Locale-Emulator](https://github.com/xupefei/Locale-Emulator.git) :转区软件,使用了其中的dll
- [2dfan@Steins;Gatex](https://2dfan.com/users/357723)的帮助及其提供的gpt-4o api key
