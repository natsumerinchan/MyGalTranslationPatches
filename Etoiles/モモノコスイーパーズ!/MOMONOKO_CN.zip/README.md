# モモノコスイーパーズ! gpt-4o-2024-11-20翻译补丁 

作者： natsumerinchan(Github) == 雨宮ゆうこ(2dfan)

已ctrl了所有内容，未出现闪退，有其它bug请反馈（截图加私发存档）

## 使用方法
- 解压压缩包并把所有文件复制到游戏根目录，双击momonoko.exe运行(无需手动转区因为UniversalInjectorFramework会自动处理)

# Credits

- [xd2333/GalTransl](https://github.com/xd2333/GalTransl.git) :支持GPT-3.5/GPT-4/Newbing/Sakura等大语言模型的Galgame自动化翻译解决方案
- [detached64/GalArc](https://github.com/detached64/GalArc.git) :Galgame解包和打包工具(取消勾选解密ybn)
- [satan53x/SExtractor](https://github.com/satan53x/SExtractor.git) :从GalGame脚本提取和导入文本(Yuris引擎+_None匹配规则)
- [AtomCrafty/UniversalInjectorFramework](https://github.com/AtomCrafty/UniversalInjectorFramework.git) :实现更改字体，jis映射

