# StrawberryNauts FHD Memorial Plus gpt-4o-2024-05-13 翻译补丁

作者： natsumerinchan(Github) == 雨宮ゆうこ(2dfan)

未作测试，可能会出现漏翻，还请多多反馈bug！！！3q
 
## 使用方法
请联合站内免DVD补丁使用
解压压缩包并把所有文件复制到游戏根目录，双击StrawberryNauts.exe运行(不需要转区)

# Credits

- [xd2333/GalTransl](https://github.com/xd2333/GalTransl.git) :支持GPT-3.5/GPT-4/Newbing/Sakura等大语言模型的Galgame自动化翻译解决方案
- [crskycode/GARbro](https://github.com/crskycode/GARbro) :Galgame解包和打包工具
- [yanhua0518/GALgameScriptTools](https://github.com/yanhua0518/GALgameScriptTools) :BGI引擎脚本提取和打包工具
- 感谢[2dfan@Steins;Gatex](https://2dfan.com/users/357723)提供的gpt-4o api key
