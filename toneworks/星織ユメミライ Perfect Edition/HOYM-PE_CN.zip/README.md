# 星織ユメミライ Perfect Edition Sakura（FishHawk-auto-novel-Sakura-LNovel-v0.9.4）翻译补丁

作者： natsumerinchan(Github) == 雨宮ゆうこ(2dfan)

仓库地址：https://github.com/natsumerinchan/HOYM-PE_CN

未作测试，可能会出现漏翻，还请多多反馈bug！！！3q

## 使用方法
(请联合站内免DVD补丁使用)

解压压缩包并把所有文件复制到游戏根目录，双击SiglusEngine_CN.exe运行（如果有的话请删除游戏目录内的reg.ini，否则需要转区运行）

首次启动本补丁请删除savedata/config.sav，以便启动游戏后更改字体（游戏现已默认使用新宋体）

### 已知BUG
- 1.游戏中的LIME App由于其字体与文本框的不同，导致其文字显示不全，但LOG中显示正常

# Credits

- [SakuraLLM/SakuraLLM](https://github.com/SakuraLLM/SakuraLLM.git) :适配轻小说/Galgame的日中翻译大模型
- [xd2333/GalTransl](https://github.com/xd2333/GalTransl.git) :支持GPT-3.5/GPT-4/Newbing/Sakura等大语言模型的Galgame自动化翻译解决方案
- [xd2333/DBTXT2Json_jp](https://github.com/xd2333/DBTXT2Json_jp.git) :通用双行文本与json_jp互转脚本
- [yanhua0518/GALgameScriptTools](https://github.com/yanhua0518/GALgameScriptTools.git) :Siglus引擎解包和打包工具
- [xmoezzz/SiglusExtract](https://github.com/xmoezzz/SiglusExtract.git) :使用了其中Universal Patch的功能，以解决修正中文显示间距，实现中日文版本共存
- [[Gal汉化入门]#6 SiglusEngine汉化教程](https://www.bilibili.com/read/cv13305423)